<template>
    <div class="container">
        <div class="row justify-content-center mt-5">
            <div class="col-12">
                <div class="card shadow text-white bg-dark">
                    <div class="card-header">Coding Challenge - Network connections</div>
                    <div class="card-body">
                        <div class="btn-group w-100 mb-3" role="group" aria-label="Basic radio toggle button group">
                            <button type="button" class="btn btn-outline-primary" :class=" isTabActive == 'suggested' ? 'active' : ''" @click="getSuggestedConnection()">Suggestions ({{ suggested.length }})</button>
                            <button type="button" class="btn btn-outline-primary" :class=" isTabActive == 'sent' ? 'active' : ''" @click="getSendConnections()">Sent Requests ()</button>
                            <button type="button" class="btn btn-outline-primary" :class=" isTabActive == 'received' ? 'active' : ''" @click="getSuggestedConnection()">Received  Requests()</button>
                            <button type="button" class="btn btn-outline-primary" :class=" isTabActive == 'connections' ? 'active' : ''" @click="getSuggestedConnection()">Connections ()</button>                          
                        </div>
                        <hr>
                        <div class="my-2 shadow  text-white bg-dark p-1" v-show="isTabActive == 'suggested'" v-for="suggest in suggested" :key="suggest.id">
                            <div class="d-flex justify-content-between">
                                <table class="ms-1">
                                    <td class="align-middle">{{ suggest.name}}</td>
                                    <td class="align-middle"> - </td>
                                    <td class="align-middle">{{ suggest.email}}</td>
                                    <td class="align-middle"> </td>
                                </table>
                                <div>
                                <button id="create_request_btn_" class="btn btn-primary me-1">Connect</button>
                                </div>
                            </div>
                        </div>

                        <div class="my-2 shadow text-white bg-dark p-1" v-show="isTabActive == 'sent'" v-for="sent in sentRequests" :key="sent.id">
                            <div class="d-flex justify-content-between">
                                <table class="ms-1">
                                    <td class="align-middle">{{ sent.name}}</td>
                                    <td class="align-middle"> - </td>
                                    <td class="align-middle">{{ sent.email}}</td>
                                    <td class="align-middle"> </td>
                                </table>
                                <div>
                                    <button id="cancel_request_btn_" class="btn btn-danger me-1" onclick="">Withdraw Request</button>
                                    <button id="accept_request_btn_" class="btn btn-primary me-1"  onclick="">Accept</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
import axios from 'axios'
export default {

    name: 'ExampleComponent',
    data() {
        return {
            suggested: [],
            sentRequests: [],
            isTabActive: ''
        }
    },
    
    methods: {
        getSuggestedConnection() {
            axios.get('/api/users')
                .then(response => {
                    this.isTabActive = 'suggested'
                    this.suggested = response.data
                })
                .catch(function (response) {
                    console.log(response)
                })
        },
        getSendConnections() {
            axios.get('/api/users')
                .then(response => {
                    this.isTabActive = 'sent'
                    this.sentRequests = response.data
                })
                .catch(function (response) {
                    console.log(response)
                })
        }
    },
    mounted() {
        this.getSuggestedConnection();
    }
}
</script>